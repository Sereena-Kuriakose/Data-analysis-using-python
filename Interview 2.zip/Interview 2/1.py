

import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

# Load the data
file_path = r"D:\Sereena Task\.idea\Interview 2\Book1.xlsx"
df = pd.read_excel(file_path, sheet_name=0)

# Convert dates
df['Created Date'] = pd.to_datetime(df['Created Date'], errors='coerce')
df['Close Date'] = pd.to_datetime(df['Close Date'], errors='coerce')
df['Close Year'] = df['Close Date'].dt.year
df['Close Month'] = df['Close Date'].dt.month

# Flag Closed Won
df['Is Won'] = df['Stage'].str.lower().str.contains('closed won', na=False)

# New vs Existing
df['Type Category'] = df['Type'].apply(lambda x: 'New' if 'new' in str(x).lower() else 'Existing')

# Summary: New vs Existing
summary_by_type = df.groupby('Type Category').agg(
    Total_Opportunities=('18 Digit Opportunity ID', 'count'),
    Total_ARR=('Opportunity ARR', 'sum'),
    Avg_ARR=('Opportunity ARR', 'mean'),
    Win_Rate=('Is Won', 'mean')
).reset_index()

# Monthly Trend
monthly = df.groupby(['Close Year', 'Close Month']).agg(
    Opportunities=('18 Digit Opportunity ID', 'count'),
    Total_ARR=('Opportunity ARR', 'sum'),
    Win_Rate=('Is Won', 'mean')
).reset_index()
monthly['Date'] = pd.to_datetime(dict(year=monthly['Close Year'], month=monthly['Close Month'], day=1))

# By State
state_stats = df.groupby('Billing State/Province').agg(
    Avg_ARR=('Opportunity ARR', 'mean'),
    Total_ARR=('Opportunity ARR', 'sum'),
    Opportunities=('18 Digit Opportunity ID', 'count'),
    Win_Rate=('Is Won', 'mean')
).reset_index()

# Forecasting 2024 ARR
won_df = df[df['Is Won']]
monthly_won = won_df.groupby(['Close Year', 'Close Month']).agg(
    ARR=('Opportunity ARR', 'sum')
).reset_index()
monthly_won['Date'] = pd.to_datetime(dict(year=monthly_won['Close Year'], month=monthly_won['Close Month'], day=1))
monthly_won['MonthIndex'] = range(1, len(monthly_won)+1)

X = monthly_won[['MonthIndex']]
y = monthly_won['ARR']
model = LinearRegression().fit(X, y)

future_months = pd.DataFrame({'MonthIndex': range(len(X)+1, len(X)+13)})
forecast = model.predict(future_months)
total_forecast_2024 = forecast.sum()
print(f"Forecasted Closed-Won ARR for 2024: ${total_forecast_2024:,.2f}")

# Data Hygiene
missing_summary = df.isnull().mean().sort_values(ascending=False)

# Save to Excel
with pd.ExcelWriter("CRM_Analysis_Summary.xlsx", engine='xlsxwriter') as writer:
    summary_by_type.to_excel(writer, sheet_name="New_vs_Existing", index=False)
    monthly.to_excel(writer, sheet_name="Monthly_Trend", index=False)
    state_stats.to_excel(writer, sheet_name="ARR_Win_by_State", index=False)
    monthly_won.to_excel(writer, sheet_name="Forecast_Model_Data", index=False)
    pd.DataFrame({'Forecasted ARR 2024': [total_forecast_2024]}).to_excel(writer, sheet_name="2024_Forecast", index=False)
    missing_summary.to_frame(name="Missing_Ratio").to_excel(writer, sheet_name="Data_Quality_Check")
